import pygame
from CONST import *

class Button1(pygame.Rect):
    def __init__(self):
        self.x = 110
        self.y = 30
        self.h = 32
        self.w = 32
